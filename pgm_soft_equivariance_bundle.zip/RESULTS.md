# REMUL soft-equivariance — results

## Theory — exact-regime gate

*GATE PASSED (6/6)*

| check | result | detail |
| --- | --- | --- |
| Prop 1 | PASS | commutant dims {'so2_x': 3, 'so2_y': 3, 'so2_z': 3, 'so3': 1} (SO3=1, SO2=3) -> OK; max rel |Delta_MC - 2||(I-P)W||^2| = 1.92e-15; gram-ordering ok=Tr |
| Thm 1 | PASS | R=0.4267 V=0.0050 lambda*=V/R=0.012; emp argmin=0.012; ER curve max rel err=2.21%; soft 0.0056 < min(unc 0.0057, hard 0.4273)=DOMINATES |
| Crossover scaling | PASS | s_cross: n100=0.176, n200=0.121, n400=0.083, n800=0.059, n1600=0.044; log-log slope=-0.502 (theory -0.500) |
| Selection recovers true residual symmetry (flips with axis; degrades at low SNR) | PASS | @ resolvable SNR (s=1.0,n=600): z-field recovers so2_z 95%, x-field recovers so2_x 95% (best group FLIPS with axis); recovery vs field s: s=0.3:97%, s |
| Learnable continuous axis recovers a NON-canonical symmetry (menu cannot) | PASS | true axis (1,2,2)/3 (off every coordinate axis); learned-axis median angular error = 0.4° over 15 seeds; continuous selector val MSE 0.7525 < best dis |
| Selection signal = achieved-min val err, NOT the lambda=0 gradient | PASS | hypergrad@0 (all <0 => non-discriminating): so2_z:-0.0085, so3:-0.0078, so2_x:-0.0031  |  achieved-min val err (discriminates): so2_z:0.7510, so3:0.75 |


## E1 — crossover scaling law

*variance-limited slope = -0.437 (theory −0.500), R²=0.97  ·  full-range slope -0.149 (saturates)*

**variance-limited slope = -0.437 (theory −0.500), R²=0.97  ·  full-range slope -0.149 (saturates)**

| n_train | s_cross |
| --- | --- |
| 120 | 8.910 |
| 180 | 8.572 |
| 270 | 6.429 |
| 400 | 5.621 |
| 600 | 4.570 |


## E3 — non-oracle group selection (validation MSE)

*recovers the axis (flips with field); over-constraining SO(3) worst everywhere*

| condition | true group | recovery | so2_x | so2_y | so2_z | so3 | no-loss |
| --- | --- | --- | --- | --- | --- | --- | --- |
| isotropic R=0 | so3 | 0% | 4.06e-04 | 3.91e-04 | 3.94e-04 | 7.46e-04 | 2.98e-04 |
| field ax0 | so2_x | 75% | 3.62e-04 | 4.04e-04 | 3.79e-04 | 7.82e-04 | 2.47e-04 |
| field ax2 | so2_z | 62% | 3.68e-04 | 3.73e-04 | 3.54e-04 | 7.54e-04 | 2.33e-04 |


## E5 — OOD robustness (the payoff)

*matched residual symmetry wins 100–1000×; axis sharply significant OOD (p<0.005)*

| field axis | true group | so2_x | so2_y | so2_z | so3 | no-loss | vs wrong p | vs so3 p |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 0 | so2_x | 9.10e-04 | 1.44e-01 | 2.08e-01 | 1.88e-03 | 1.44e+00 | 0.004 | 0.0000 |
| 2 | so2_z | 2.35e-01 | 3.36e-01 | 9.21e-04 | 1.87e-03 | 2.13e+00 | 0.000 | 0.0000 |


## E2 — interior optimum β* (Thm 1 transfer)

*OOD wants β*>0; over-constraining SO(3) wants LESS (0.3<1.0) — exactly λ*=V/R*

| group | argmin β (in-dist) | argmin β (OOD) | interior OOD optimum |
| --- | --- | --- | --- |
| so2_z | 0.03 | 1 | yes |
| so3 | 0.03 | 0.3 | yes |


## Learnable continuous axis (deep net)

*identifies the correct dominant axis 100% of seeds; ~38° residual (vs 0.4° in sandbox)*

| field axis | median angle° | min° | max° | dominant-axis-correct |
| --- | --- | --- | --- | --- |
| z | 37.6 | 34.3 | 38.0 | 100% |
| x | 39.4 | 38.7 | 42.0 | 100% |


## R1 — matched-enforcement RQ1 null

*enforcement explains 80% of MAE; schedule shape adds ~0; 'scheduling helps' was a confound*

| statistic | value |
| --- | --- |
| Spearman(MAE, achieved E') | -0.786 (p=4.3e-07) |
| MAE ~ log(E') R² | 0.799 |
| schedule-shape residual (MAE) | +0.0008 ± 0.0086 |
| no-loss baseline MAE | 0.2201 (lowest) |


## E6 — CMU MoCap (real data) OOD robustness

*matched SO(2)_y most robust · vs wrong-axis p=0.011, vs SO(3) p=0.005, vs no-loss p=0.334*

matched SO(2)_y most robust · vs wrong-axis p=0.011, vs SO(3) p=0.005, vs no-loss p=0.334

| group | OOD-MSE | degrade× |
| --- | --- | --- |
| so2_y | 8.51e-03 | 1.06 |
| so2_x | 1.03e-02 | 1.29 |
| so2_z | 9.51e-03 | 1.16 |
| so3 | 8.90e-03 | 1.11 |
| no-loss | 1.43e-02 | — |


## DA vs REMUL — compute-matched premise test

*Known symmetry: augmentation WINS OOD (3.7×). REMUL's niche is graceful degradation under a wrong/over group (2.1× better in-dist than DA-SO(3)) + it is the vehicle for group selection. Don't claim 'soft loss beats augmentation'.*

| method | in-dist MSE | OOD MSE |
| --- | --- | --- |
| no-loss | 1.06e-04 | 3.48e+00 |
| DA · matched | 2.59e-04 | 2.56e-04 |
| REMUL · matched | 3.62e-04 | 9.44e-04 |
| DA · over SO(3) | 1.59e-03 | 1.59e-03 |
| REMUL · over SO(3) | 7.54e-04 | 1.95e-03 |
| DA · wrong axis | 2.46e-04 | 3.25e-01 |
| REMUL · wrong axis | 4.01e-04 | 2.05e-01 |


## Cross-backbone replication (OOD robustness)

*matched residual symmetry is the most OOD-robust on mlp, transformer AND gnn (matched ≪ wrong-axis, p≤0.001 everywhere; 5 seeds each)*

| backbone | matched OOD | wrong-axis OOD | over-SO3 OOD | no-loss OOD | matched<wrong p | matched<over p |
| --- | --- | --- | --- | --- | --- | --- |
| mlp | 9.39e-04 | 2.22e-01 | 1.96e-03 | 2.12e+00 | 0.001 | 0.000 |
| transformer | 1.73e-05 | 2.25e-03 | 1.85e-05 | 2.67e-03 | 0.000 | 0.069 |
| gnn | 8.40e-05 | 4.28e-03 | 1.10e-04 | 4.73e-03 | 0.000 | 0.016 |


## Group selection: REMUL vs augmentation

*You cannot 'select an augmentation' — a wrong DA still fits validation (38%, ≈chance). REMUL-selection recovers the true residual axis 88% — a wrong penalty conflicts with the task and cleanly raises val error.*

| selection method | z-field | x-field | overall recovery |
| --- | --- | --- | --- |
| DA-selection | 25% | 50% | 38% (≈chance) |
| REMUL-selection | 75% | 100% | 88% |


## Data-scaling — is the OOD advantage a small-data artifact?

*No. The matched-group OOD advantage is ~1500-2200x vs no-loss and FLAT across a 20x range of n_train (no-loss never sees the OOD orientations regardless of data size).*

| arm | n=200 | n=500 | n=1000 | n=2000 | n=4000 |
| --- | --- | --- | --- | --- | --- |
| no-loss | 1.86e+00 | 1.47e+00 | 2.03e+00 | 1.83e+00 | 1.56e+00 |
| matched | 1.22e-03 | 9.26e-04 | 9.19e-04 | 8.94e-04 | 9.26e-04 |
| wrong-axis | 9.56e-02 | 1.00e-01 | 1.92e-01 | 1.96e-01 | 2.30e-01 |
| over-SO3 | 2.04e-03 | 1.83e-03 | 1.90e-03 | 1.76e-03 | 1.94e-03 |


## Baselines — who can recover WHICH symmetry?

*REMUL recovers the residual axis (88% select / 100% learnable) via its ground-truth-anchored loss. Augerino CANNOT (isotropic at every λ) because augmentation-based discovery conflates task-symmetry with input-distribution symmetry. DA is strongest IF the group is known.*

| method | recovers residual axis? | OOD MSE | needs known group? |
| --- | --- | --- | --- |
| REMUL-selection | 88% | 9.44e-04 | no |
| REMUL learnable-axis | 100% dominant | 9.44e-04 | no |
| Augerino | 0% (isotropic, z/xy=1.0) | 2.30e-03 | no |
| Data augmentation | n/a (given) | 2.56e-04 | YES |
| RPP (relaxed arch) | n/a (fixed arch) | 7.64e-03 | fixed |
| EMLP (equiv arch) | n/a (fixed arch) | 1.24e-03 | fixed |
| no-loss | — | 3.48e+00 | — |


## Label-breaks-symmetry wedge — REMUL vs LieGAN vs Augerino

*Isotropic inputs (SO(3)-symmetric p(x)) + z-field (SO(2)_z task). LieGAN discovers the INPUT symmetry SO(3) and misses the label-breaking; REMUL anchors on the TASK (‖f(Rx)−Ry‖, so2_z err=0.0000). REMUL is the ONLY method that recovers the task symmetry on BOTH fixed-frame AND isotropic inputs.*

| group | LieGAN input-MMD | task-equiv error | is task symmetry? |
| --- | --- | --- | --- |
| so2_z | 0.0003 | 0.0000 | YES |
| so2_x | 0.0003 | 0.0893 | no |
| so3 | 0.0003 | 0.0883 | no |


| method (basis) | fixed-frame inputs | isotropic inputs |
| --- | --- | --- |
| REMUL (task-anchored loss) | ✓ (88% select) | ✓ (task-equiv=0) |
| Augerino (task averaging) | ✗ (isotropic θ) | ✓ (θz/θxy=18) |
| LieGAN (input distribution) | — (no clean input sym) | ✗ (finds SO(3)) |


## #4/#5 — graphs: scheduling null on OOD + equivariance robustness

*The scheduling null extends to OOD (not in-distribution-only). Enforcing the symmetry reduces the rotation-OOD gap ~27x on graphs (payoff direction transfers). Group-selection is dynamics-specific (QM9 fully symmetric).*

| question | result |
| --- | --- |
| #4 scheduling null on OOD (QM9) | Spearman(OOD-MAE,E')=-0.63 (p=2e-03); schedule-shape residual +0.0018±0.0026 -> null holds on OOD |
| #5 equivariance->rotation robustness (QM9) | OOD-gap vs E_prime Spearman=0.88 (p=2e-07); gap 0.067 (no-loss) -> 0.0025 (enforced), ~27x |
| #5 scope (honest) | group-SELECTION story is dynamics-specific: QM9 is fully SO(3)-symmetric (no partial symmetry to select); 2nd graph dataset blocked (pyg-lib/MD17-graph) |


## Model-zoo × dataset grid

*strict-equivariant models are strong on clean SO(3) tasks but DIVERGE (⚠) on real partial-symmetry data (mocap); unconstrained &amp; relaxed are robust across the spectrum. E' orders the models: strict≈1e-7 → soft → unconstrained≈1.*

| model (equiv class) | nbody_so3 | nbody_broken | nbody_charged | md17 | mocap |
| --- | --- | --- | --- | --- | --- |
| egnn · strict | 1.19e-04 | 4.70e-04 | 4.46e-05 | 2.01e-01 | 1.15e-01 ⚠ |
| se3_transformer · strict | 1.23e-04 | 3.63e-04 | 2.74e-05 | 2.11e-01 | 2.83e-02 ⚠ |
| gatr · strict | 7.43e-04 | 4.75e-04 | 5.81e-04 | 2.07e-01 | 1.32e+03 ⚠ |
| emlp · strict | 1.12e-03 | 1.24e-03 | 2.88e-04 | 2.97e-01 | 1.40e-02 |
| rpp · relaxed-arch | 1.58e-04 | 1.36e-04 | 3.07e-04 | 1.46e-01 | 1.18e-02 |
| mlp · unconstrained | 4.80e-04 | 3.59e-04 | 3.39e-04 | 1.57e-01 | 8.57e-03 |
| transformer · unconstrained | 8.41e-05 | 6.76e-05 | 8.60e-05 | 1.65e-01 | 8.12e-03 |
| mlp_remul_so3 · soft-loss | 1.36e-03 | 1.32e-03 | 3.09e-04 | 1.57e-01 | 2.69e-02 ⚠ |


**Equivariance spectrum (E')**

| model | equiv class | equivariance error E' |
| --- | --- | --- |
| emlp | strict | 4.13e-07 |
| se3_transformer | strict | 1.36e-06 |
| egnn | strict | 1.65e-06 |
| gatr | strict | 8.12e-06 |
| mlp_remul_so3 | soft-loss | 5.75e-01 |
| transformer | unconstrained | 1.49e+00 |
| rpp | relaxed-arch | 2.68e+00 |
| mlp | unconstrained | 4.48e+00 |


